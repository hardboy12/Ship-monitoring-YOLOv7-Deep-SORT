# vim: expandtab:ts=4:sw=4
from __future__ import absolute_import
import numpy as np
from . import linear_assignment


def diou(bbox, candidates):
    """Compute Distance Intersection over Union (DIoU).

    Parameters
    ----------
    bbox : ndarray
        A bounding box in format `(top left x, top left y, width, height)`.
    candidates : ndarray
        A matrix of candidate bounding boxes (one per row) in the same format
        as `bbox`.

    Returns
    -------
    ndarray
        The DIoU values in [-1, 1] between the `bbox` and each candidate.
        A higher score means the `bbox` is more similar to the candidate.

    """
    bbox_tl, bbox_br = bbox[:2], bbox[:2] + bbox[2:]
    candidates_tl = candidates[:, :2]
    candidates_br = candidates[:, :2] + candidates[:, 2:]

    # Compute intersection
    tl = np.c_[np.maximum(bbox_tl[0], candidates_tl[:, 0])[:, np.newaxis],
               np.maximum(bbox_tl[1], candidates_tl[:, 1])[:, np.newaxis]]
    br = np.c_[np.minimum(bbox_br[0], candidates_br[:, 0])[:, np.newaxis],
               np.minimum(bbox_br[1], candidates_br[:, 1])[:, np.newaxis]]
    wh = np.maximum(0., br - tl)
    area_intersection = wh.prod(axis=1)

    # Compute union
    area_bbox = bbox[2:].prod()
    area_candidates = candidates[:, 2:].prod(axis=1)
    iou = area_intersection / (area_bbox + area_candidates - area_intersection)

    # Compute center distances
    bbox_center = bbox[:2] + bbox[2:] / 2
    candidates_center = candidates[:, :2] + candidates[:, 2:] / 2
    center_distances = np.sum((bbox_center - candidates_center) ** 2, axis=1)

    # Compute enclosing box diagonal
    enclosing_tl = np.minimum(bbox_tl, candidates_tl)
    enclosing_br = np.maximum(bbox_br, candidates_br)
    enclosing_wh = np.maximum(0., enclosing_br - enclosing_tl)
    enclosing_diagonal = np.sum(enclosing_wh ** 2, axis=1)

    # Compute DIoU
    diou = iou - center_distances / (enclosing_diagonal + 1e-7)
    return diou


def diou_cost(tracks, detections, track_indices=None,
              detection_indices=None):
    """A Distance Intersection over Union (DIoU) distance metric.

    Parameters
    ----------
    tracks : List[deep_sort.track.Track]
        A list of tracks.
    detections : List[deep_sort.detection.Detection]
        A list of detections.
    track_indices : Optional[List[int]]
        A list of indices to tracks that should be matched. Defaults to
        all `tracks`.
    detection_indices : Optional[List[int]]
        A list of indices to detections that should be matched. Defaults
        to all `detections`.

    Returns
    -------
    ndarray
        Returns a cost matrix of shape
        len(track_indices), len(detection_indices) where entry (i, j) is
        `1 - diou(tracks[track_indices[i]], detections[detection_indices[j]])`.

    """
    if track_indices is None:
        track_indices = np.arange(len(tracks))
    if detection_indices is None:
        detection_indices = np.arange(len(detections))

    cost_matrix = np.zeros((len(track_indices), len(detection_indices)))
    for row, track_idx in enumerate(track_indices):
        if tracks[track_idx].time_since_update > 1:
            cost_matrix[row, :] = linear_assignment.INFTY_COST
            continue

        bbox = tracks[track_idx].to_tlwh()
        candidates = np.asarray([detections[i].tlwh for i in detection_indices])
        cost_matrix[row, :] = 1. - diou(bbox, candidates)
    return cost_matrix
