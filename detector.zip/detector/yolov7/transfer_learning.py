import argparse
import torch
from torch.optim import Adam
from models.yolo import Model
from utils.datasets import create_dataloader
from utils.general import check_dataset, check_img_size, increment_path
from utils.loss import ComputeLoss
from utils.torch_utils import select_device

def transfer_learning(data, weights, epochs, batch_size, img_size, device=''):
    # Device setup
    device = select_device(device)
    
    # Load dataset
    with open(data) as f:
        dataset = check_dataset(f.read())
    train_path, val_path = dataset['train'], dataset['val']

    # Load YOLOv7 model
    model = Model('cfg/training/yolov7.yaml', ch=3, nc=dataset['nc']).to(device)
    checkpoint = torch.load(weights, map_location=device)
    model.load_state_dict(checkpoint['model'], strict=False)
    print("Loaded pretrained weights.")

    # Freeze layers if needed
    for param in model.parameters():
        param.requires_grad = True  # Set all layers trainable
    
    # Create dataloader
    train_loader, _ = create_dataloader(train_path, img_size, batch_size, 32, augment=True)
    
    # Loss function
    compute_loss = ComputeLoss(model)
    
    # Optimizer setup (Adam)
    optimizer = Adam(model.parameters(), lr=0.001)
    
    # Training loop
    for epoch in range(epochs):
        model.train()
        running_loss = 0.0
        
        for batch_idx, (imgs, targets, paths, _) in enumerate(train_loader):
            imgs = imgs.to(device).float() / 255.0  # Normalize to [0, 1]
            targets = targets.to(device)

            # Forward pass
            outputs = model(imgs)
            loss, _ = compute_loss(outputs, targets)

            # Backward pass
            optimizer.zero_grad()
            loss.backward()
            optimizer.step()

            running_loss += loss.item()
        
        print(f"Epoch [{epoch + 1}/{epochs}], Loss: {running_loss / len(train_loader):.4f}")
    
    # Save the fine-tuned model
    save_dir = increment_path('./runs/transfer', exist_ok=False)
    save_path = f"{save_dir}/yolov7_finetuned.pt"
    torch.save({'model': model.state_dict()}, save_path)
    print(f"Model saved to {save_path}")

if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument('--data', type=str, required=True, help='Path to dataset YAML file')
    parser.add_argument('--weights', type=str, required=True, help='Path to pretrained weights')
    parser.add_argument('--epochs', type=int, default=50, help='Number of training epochs')
    parser.add_argument('--batch-size', type=int, default=16, help='Batch size')
    parser.add_argument('--img-size', type=int, default=640, help='Image size')
    parser.add_argument('--device', type=str, default='', help='CUDA device, i.e., 0 or 0,1,2,3')
    args = parser.parse_args()

    transfer_learning(
        data=args.data,
        weights=args.weights,
        epochs=args.epochs,
        batch_size=args.batch_size,
        img_size=args.img_size,
        device=args.device
    )
